<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'insuranc_databas');

/** MySQL database username */
define('DB_USER', 'insuranc_databas');

/** MySQL database password */
define('DB_PASSWORD', 'insuranc_databas');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'onb3yaphkxfb6oipxxoidtak7msj0gaxlljih6pm34aglimh4fthircpuycj3cns');
define('SECURE_AUTH_KEY',  'svhrent4rus1u51tkmqoadgcghms9b9jjogbbbpwbhbws6irsedewh4dinenay5p');
define('LOGGED_IN_KEY',    'fxz1iyllgifezfvn5j9gqeuhhnd73fln4u2ablvbdz1sdswbx57bjdwng3i3pg3n');
define('NONCE_KEY',        'pqhyjreqfvgrdt5x1cxjgewio8nbr9rxkuuz0duaajrocjaaatgg7jeiresz9kso');
define('AUTH_SALT',        'lmthjpdck4rrk6jocpkwdxrajyvski1jvr63j4exsgonpkag7vyhf5hdhkp5blp6');
define('SECURE_AUTH_SALT', 'ld4jj8tccso1tnzaaufvk2cotsy5fndktxj1o4pe7wt0fwayjtjpjdfzcuyol6t5');
define('LOGGED_IN_SALT',   'ac8m0xfeqtkdzjsvadgn7qsckgnufdubyjxw1m0ran6z0qc8e3d2ti1mauacphyz');
define('NONCE_SALT',       '729z9i2idiffb4t8zkulzkjjsarvk5ytanv66mcygf5pezajpfsx9ospks1u4ibc');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wpba_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
